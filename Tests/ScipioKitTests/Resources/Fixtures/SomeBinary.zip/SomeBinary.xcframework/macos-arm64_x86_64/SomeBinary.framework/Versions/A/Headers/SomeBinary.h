//
//  SomeBinary.h
//  SomeBinary
//
//  Created by JP30698 on 2022/12/02.
//

#import <Foundation/Foundation.h>

//! Project version number for SomeBinary.
FOUNDATION_EXPORT double SomeBinaryVersionNumber;

//! Project version string for SomeBinary.
FOUNDATION_EXPORT const unsigned char SomeBinaryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SomeBinary/PublicHeader.h>


